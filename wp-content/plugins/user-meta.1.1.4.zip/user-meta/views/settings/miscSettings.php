<?php
global $userMeta;

$html = "<p>" . sprintf( __( 'This feature is only supported in Pro version. Get %s', $userMeta->name ), "<a href='{$userMeta->website}'>User Meta Pro</a>" ) . "</p>";

?>
