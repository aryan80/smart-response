<?php
/* 
 * emailer form processor
 * sends out the form data as an email
 */

    $Title = 'Akismet';
    $Desc = 'Filters out spam inputs and flags or deletes the entry.';

?>
