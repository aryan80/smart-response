<?php
/* 
 * wordpress login form processor
 * processess the form as a wordpress login then captures the submition as a login.
 */
    $Title = 'Wordpress Login';
    $Desc = 'Processess form as a Wordpress login.';


?>
