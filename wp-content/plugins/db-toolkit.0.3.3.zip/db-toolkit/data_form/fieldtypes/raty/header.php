<?php
        wp_register_script('DBT_raty', WP_PLUGIN_URL. '/db-toolkit/data_form/fieldtypes/raty/js/jquery.raty.min.js', 'jquery', false, true);
        wp_enqueue_script("DBT_raty");
?>