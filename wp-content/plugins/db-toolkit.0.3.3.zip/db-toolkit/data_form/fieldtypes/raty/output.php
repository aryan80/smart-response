<?php
// $Out

//$Out .= $Data[$Field];

$Out .= raty_processValue($Data[$Field], $Type, $Field, $Config, $EID);

?>