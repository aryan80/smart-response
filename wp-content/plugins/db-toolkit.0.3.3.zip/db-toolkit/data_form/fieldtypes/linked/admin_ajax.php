<?php
	declare_ajax_functions('linked_loadfields', 'linked_loadfilterfields', 'linked_loadAdditionalValue');
?>