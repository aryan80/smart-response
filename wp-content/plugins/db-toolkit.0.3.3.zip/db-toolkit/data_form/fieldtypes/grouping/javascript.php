<?php 

// add any additional javascript required for the field type.

?>