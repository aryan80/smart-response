<?php
 //anything to be added to the page footers e.g. javascript
?>