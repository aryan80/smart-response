<?php
	// Declares 
	declare_ajax_functions();
?>