<?php
	//declare_ajax_functions('');
?>