<?php
/// This creates the actual input fields for capturing. this will handle the occurance of the setting
//echo '<input name="dataForm['.$Element['ID'].']['.$Field.']" type="text" id="entry_'.$Element['ID'].'_'.$Field.'" value="sessionID" class="textfield '.$Req.'" />';

?>