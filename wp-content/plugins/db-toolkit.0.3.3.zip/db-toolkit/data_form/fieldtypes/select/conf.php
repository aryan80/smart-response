<?php
// Field Types Config| 
$FieldTypeTitle = 'Select Input';
$isVisible = true;
$FieldTypes = array();

$FieldTypes['selects'] 	= array('name' => 'Select Options', 'func' => 'select_setup', 'visible' => true, 'baseType'  => 'TEXT');


?>