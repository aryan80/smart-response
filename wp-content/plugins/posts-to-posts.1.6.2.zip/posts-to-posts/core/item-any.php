<?php

class P2P_Item_Any extends P2P_Item {

	function __construct() {}

	function get_permalink() {}

	function get_title() {}

	function get_object() {
		return 'any';
	}

	function get_id() {
		return false;
	}
}

